"""
BuySafe Financial Decision Engine

Core responsibilities:
1. Parse seller CSV data
2. Forecast cash flow
3. Determine SAFE / UNSAFE purchase decisions
4. Calculate maximum safe purchase
5. Calculate earliest safe purchase date

Uses only Python standard-library modules.
"""

from datetime import datetime, timedelta
from decimal import Decimal
from dataclasses import dataclass
from typing import List, Dict, Optional
import csv
import io


# ---------------------------------------------------------
# DATA MODEL
# ---------------------------------------------------------

@dataclass
class Transaction:
    date: datetime
    type: str
    amount: Decimal
    description: str


@dataclass
class CashFlowResult:
    min_balance: Decimal
    min_balance_date: datetime
    is_safe: bool
    final_balance: Decimal


# ---------------------------------------------------------
# CSV PARSER
# ---------------------------------------------------------

def parse_transactions(csv_content: str) -> List[Transaction]:
    """
    Parse CSV content into Transaction objects.

    Expected columns:
    date,type,amount,description
    """

    if not csv_content.strip():
        return []

    transactions = []

    reader = csv.DictReader(io.StringIO(csv_content.strip()))

    required_columns = {"date", "type", "amount", "description"}

    if not reader.fieldnames:
        raise ValueError("CSV is missing headers")

    missing = required_columns - set(reader.fieldnames)

    if missing:
        raise ValueError(
            f"CSV missing required columns: {', '.join(sorted(missing))}"
        )

    for row_number, row in enumerate(reader, start=2):
        try:
            date = datetime.strptime(
                row["date"].strip(),
                "%Y-%m-%d"
            )

            amount = Decimal(row["amount"].strip())

            transaction_type = row["type"].strip().lower()
            description = row["description"].strip()

            if amount < 0:
                raise ValueError("Transaction amount cannot be negative")

            transactions.append(
                Transaction(
                    date=date,
                    type=transaction_type,
                    amount=amount,
                    description=description
                )
            )

        except Exception as exc:
            raise ValueError(
                f"Invalid transaction on CSV row {row_number}: {exc}"
            ) from exc

    return transactions


# ---------------------------------------------------------
# TRANSACTION ORDER
# ---------------------------------------------------------

def transaction_priority(transaction_type: str) -> int:
    """
    Deterministic ordering for transactions occurring
    on the same date.

    Incoming money is processed before outgoing money.
    """

    if transaction_type in ["amazon_payout", "refund"]:
        return 1

    if transaction_type in ["expense", "fee"]:
        return 2

    if transaction_type == "inventory":
        return 3

    return 4


def sort_transactions(
    transactions: List[Transaction]
) -> List[Transaction]:

    return sorted(
        transactions,
        key=lambda transaction: (
            transaction.date,
            transaction_priority(transaction.type)
        )
    )


# ---------------------------------------------------------
# CASH FLOW CALCULATION
# ---------------------------------------------------------

def calculate_cash_flow(
    current_cash: float,
    transactions: List[Transaction],
    reserve_threshold: float,
    purchase_amount: float = 0,
    purchase_date: Optional[str] = None
) -> CashFlowResult:

    balance = Decimal(str(current_cash))
    reserve = Decimal(str(reserve_threshold))

    all_transactions = list(transactions)

    # Add hypothetical inventory purchase
    if purchase_amount > 0:

        if not purchase_date:
            raise ValueError(
                "purchase_date is required when purchase_amount > 0"
            )

        purchase_datetime = datetime.strptime(
            purchase_date,
            "%Y-%m-%d"
        )

        all_transactions.append(
            Transaction(
                date=purchase_datetime,
                type="inventory",
                amount=Decimal(str(purchase_amount)),
                description="Hypothetical inventory purchase"
            )
        )

    sorted_transactions = sort_transactions(all_transactions)

    min_balance = balance

    if sorted_transactions:
        min_balance_date = sorted_transactions[0].date
    else:
        min_balance_date = datetime.strptime(
            "1970-01-01",
            "%Y-%m-%d"
        )

    for transaction in sorted_transactions:

        if transaction.type in ["amazon_payout", "refund"]:
            balance += transaction.amount

        elif transaction.type in ["expense", "fee", "inventory"]:
            balance -= transaction.amount

        else:
            raise ValueError(
                f"Unknown transaction type: {transaction.type}"
            )

        if balance < min_balance:
            min_balance = balance
            min_balance_date = transaction.date

    is_safe = min_balance >= reserve

    return CashFlowResult(
        min_balance=min_balance,
        min_balance_date=min_balance_date,
        is_safe=is_safe,
        final_balance=balance
    )


# ---------------------------------------------------------
# MAXIMUM SAFE PURCHASE
# ---------------------------------------------------------

def calculate_max_safe_purchase(
    current_cash: float,
    transactions: List[Transaction],
    reserve_threshold: float,
    purchase_date: str
) -> int:
    """
    Find the maximum purchase amount that keeps
    projected cash >= reserve threshold.

    Uses binary search.
    """

    low = 0
    high = int(current_cash)

    while low < high:

        mid = (low + high + 1) // 2

        result = calculate_cash_flow(
            current_cash=current_cash,
            transactions=transactions,
            reserve_threshold=reserve_threshold,
            purchase_amount=mid,
            purchase_date=purchase_date
        )

        if result.is_safe:
            low = mid
        else:
            high = mid - 1

    return low


# ---------------------------------------------------------
# EARLIEST SAFE DATE
# ---------------------------------------------------------

def calculate_earliest_safe_date(
    current_cash: float,
    transactions: List[Transaction],
    reserve_threshold: float,
    purchase_amount: float,
    start_date: str,
    days_to_check: int = 30
) -> Optional[str]:
    """
    Find the earliest date within the next N days
    where the specified purchase is safe.
    """

    start = datetime.strptime(
        start_date,
        "%Y-%m-%d"
    )

    for days_ahead in range(days_to_check + 1):

        candidate_date = (
            start + timedelta(days=days_ahead)
        )

        candidate_date_string = candidate_date.strftime(
            "%Y-%m-%d"
        )

        result = calculate_cash_flow(
            current_cash=current_cash,
            transactions=transactions,
            reserve_threshold=reserve_threshold,
            purchase_amount=purchase_amount,
            purchase_date=candidate_date_string
        )

        if result.is_safe:
            return candidate_date_string

    return None


def calculate_daily_timeline(
    current_cash: float,
    transactions: List[Transaction],
    purchase_amount: float = 0,
    purchase_date: Optional[str] = None,
    start_date: Optional[str] = None,
    days: int = 30
) -> List[Dict]:
    """
    Generate daily cash balance timeline for charting directly from engine calculations.
    """
    if start_date:
        start = datetime.strptime(start_date, "%Y-%m-%d")
    elif transactions:
        start = min(t.date for t in transactions)
    else:
        start = datetime.now()

    all_transactions = list(transactions)
    if purchase_amount > 0 and purchase_date:
        purchase_dt = datetime.strptime(purchase_date, "%Y-%m-%d")
        all_transactions.append(
            Transaction(
                date=purchase_dt,
                type="inventory",
                amount=Decimal(str(purchase_amount)),
                description="Hypothetical inventory purchase"
            )
        )

    tx_by_date = {}
    for tx in all_transactions:
        d_str = tx.date.strftime("%Y-%m-%d")
        if d_str not in tx_by_date:
            tx_by_date[d_str] = []
        tx_by_date[d_str].append(tx)

    timeline = []
    balance = Decimal(str(current_cash))

    for day_offset in range(days):
        day_dt = start + timedelta(days=day_offset)
        d_str = day_dt.strftime("%Y-%m-%d")
        label = day_dt.strftime("%b %d")

        # Inflows first
        for tx in tx_by_date.get(d_str, []):
            if tx.type in ["amazon_payout", "refund"]:
                balance += tx.amount

        # Outflows second
        for tx in tx_by_date.get(d_str, []):
            if tx.type in ["expense", "fee", "inventory"]:
                balance -= tx.amount

        timeline.append({
            "dateKey": d_str,
            "date": label,
            "cash": int(round(balance))
        })

    return timeline


def generate_calculation_trace(
    current_cash: float,
    transactions: List[Transaction],
    reserve_threshold: float,
    purchase_amount: float,
    purchase_date: str,
    min_balance: Decimal,
    min_balance_date: datetime,
    max_safe: int,
    status: str
) -> Dict:
    """
    Generate an auditable, step-by-step mathematical trace of the engine's calculation.
    Similar to a financial diagnostics / verification panel.
    """
    steps = []
    balance = Decimal(str(current_cash))

    steps.append({
        "step": 1,
        "date": purchase_date,
        "action": "Starting Liquid Balance",
        "type": "balance",
        "delta": 0,
        "balance": float(balance),
        "is_trough": False,
        "note": "Verified available cash in seller bank account"
    })

    all_txs = list(transactions)
    if purchase_amount > 0:
        p_date = datetime.strptime(purchase_date, "%Y-%m-%d")
        all_txs.append(
            Transaction(
                date=p_date,
                type="inventory",
                amount=Decimal(str(purchase_amount)),
                description=f"Proposed Order (₹{purchase_amount:,.0f})"
            )
        )

    sorted_txs = sort_transactions(all_txs)
    step_num = 2
    cur_bal = Decimal(str(current_cash))

    for tx in sorted_txs:
        d_str = tx.date.strftime("%Y-%m-%d")
        is_inflow = tx.type in ["amazon_payout", "refund"]
        amt = tx.amount
        delta = float(amt) if is_inflow else -float(amt)
        cur_bal += (amt if is_inflow else -amt)

        is_trough = (tx.date == min_balance_date and cur_bal == min_balance)

        steps.append({
            "step": step_num,
            "date": d_str,
            "action": f"{tx.description}",
            "type": tx.type,
            "delta": delta,
            "balance": float(cur_bal),
            "is_trough": is_trough,
            "note": "Lowest cash point (Safety Bottom)" if is_trough else ""
        })
        step_num += 1

    reserve_dec = Decimal(str(reserve_threshold))
    margin = float(min_balance - reserve_dec)

    return {
        "starting_cash": float(current_cash),
        "purchase_amount": float(purchase_amount),
        "trough_cash": float(min_balance),
        "trough_date": min_balance_date.strftime("%Y-%m-%d"),
        "reserve_threshold": float(reserve_threshold),
        "margin": margin,
        "shortfall": max(0.0, -margin),
        "max_safe_purchase": max_safe,
        "status": status,
        "rule": "Projected Cash Floor >= Reserve Buffer",
        "formula_proof": f"₹{float(min_balance):,.0f} {'≥' if status == 'SAFE' else '<'} ₹{float(reserve_threshold):,.0f}",
        "steps": steps
    }


# ---------------------------------------------------------
# MAIN EVALUATION FUNCTION
# ---------------------------------------------------------

def evaluate_purchase(
    current_cash: float,
    reserve_threshold: float,
    purchase_amount: float,
    csv_data: str,
    purchase_date: Optional[str] = None,
    analysis_date: Optional[str] = None
) -> Dict:

    transactions = parse_transactions(csv_data)

    if analysis_date is None:

        if transactions:
            analysis_date = min(
                transaction.date for transaction in transactions
            ).strftime("%Y-%m-%d")

        else:
            analysis_date = datetime.now().strftime("%Y-%m-%d")

    # If no purchase date was supplied, analyze from analysis date
    if purchase_amount > 0 and purchase_date is None:
        purchase_date = analysis_date

    result = calculate_cash_flow(
        current_cash=current_cash,
        transactions=transactions,
        reserve_threshold=reserve_threshold,
        purchase_amount=purchase_amount,
        purchase_date=purchase_date
    )

    max_safe = calculate_max_safe_purchase(
        current_cash=current_cash,
        transactions=transactions,
        reserve_threshold=reserve_threshold,
        purchase_date=analysis_date
    )

    earliest_safe = None

    if purchase_amount > 0:

        earliest_safe = calculate_earliest_safe_date(
            current_cash=current_cash,
            transactions=transactions,
            reserve_threshold=reserve_threshold,
            purchase_amount=purchase_amount,
            start_date=analysis_date
        )

    reserve = Decimal(str(reserve_threshold))

    shortfall = max(
        Decimal("0"),
        reserve - result.min_balance
    )

    daily_forecast = calculate_daily_timeline(
        current_cash=current_cash,
        transactions=transactions,
        purchase_amount=purchase_amount,
        purchase_date=purchase_date,
        start_date=analysis_date,
        days=30
    )

    status_str = "SAFE" if result.is_safe else "UNSAFE"

    calculation_trace = generate_calculation_trace(
        current_cash=current_cash,
        transactions=transactions,
        reserve_threshold=reserve_threshold,
        purchase_amount=purchase_amount,
        purchase_date=purchase_date or analysis_date,
        min_balance=result.min_balance,
        min_balance_date=result.min_balance_date,
        max_safe=max_safe,
        status=status_str
    )

    return {
        "status": status_str,
        "purchase_amount": purchase_amount,
        "minimum_projected_cash": float(result.min_balance),
        "reserve_threshold": reserve_threshold,
        "shortfall": float(shortfall),
        "maximum_safe_purchase": max_safe,
        "earliest_safe_date": earliest_safe,
        "min_balance_date": result.min_balance_date.strftime("%Y-%m-%d"),
        "final_balance": float(result.final_balance),
        "daily_forecast": daily_forecast,
        "calculation_trace": calculation_trace
    }
